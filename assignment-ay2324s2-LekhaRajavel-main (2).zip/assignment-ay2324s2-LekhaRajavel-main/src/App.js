import AddEntityForm from './AddEntityForm.js';

export default function App() {
    return <div>

        <AddEntityForm/>
    </div>;
}
