export const AddEntityCategoryTestId = 'add-entity-category';
export const AddEntitySubmitTestId = 'submit-add-entity';
export const DeleteSelectedTestId = 'delete-selected';
export const EntityTestId = 'entity';
export const EntitySelectTestId = 'entity-select';
export const EntityDeleteTestId = 'entity-delete';
export const EntityCategoryTestId = 'entity-category';
export const FilterCategoryTestId = 'filter-category';
