const config = {
    testEnvironment: 'jsdom',
};

export default config;
